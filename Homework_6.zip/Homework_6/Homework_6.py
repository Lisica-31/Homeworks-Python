visit_f = open ('visit_log__1_.csv', 'r', encoding = 'utf-8')
purchase_f = open ('purchase_log.txt', 'r', encoding = 'utf-8')

visit_title = visit_f.readline()
visit_line = visit_f.readline()
purchase_title = purchase_f.readline()
purchase_line = purchase_f.readline()

purchases = {}
for purchase_line in purchase_f:
    parts = purchase_line.strip().strip('{}').rstrip('}').split(', ')
    purchase_user_id = parts[0].split(': ')[1].replace('"', '').strip()
    category = parts[1].split(': ')[1].replace('"', '').strip()
    purchases[purchase_user_id] = category

with open ('funnel.csv', 'w', encoding = 'utf-8') as funnel_f:
    funnel_f.write('user_id, source, category\n')
    
    for visit_line in visit_f:
        visit_user_id, source = visit_line.split(',')
        source = source.strip().replace('\n', '').replace('\r', '')

        if visit_user_id in purchases:
            category = purchases[visit_user_id]
            funnel_f.write(f'{visit_user_id}, {source}, {category}\n')
